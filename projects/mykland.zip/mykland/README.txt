JackCompiler.py doesn’t run properly, and I’ve spent a long time trying to debug but I can’t figure out what is wrong. However, it should in theory be implemented correctly.


Makes sure JackCompiler.py is in the same directory as the rest of the project 11 files. In terminal, enter “python3 /path/of/file/JackCompiler.py /path/of/test/file” (Or whatever version of python is installed on your system). Do not include the “.jack” extension for “file.jack”.

This should generate “file.vm”.



